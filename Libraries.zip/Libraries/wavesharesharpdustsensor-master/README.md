# wavesharesharpdustsensor
Arduino library for Waveshare's Sharp Infrared Dust Sensor breakout board
